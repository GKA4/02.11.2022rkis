let str = 'xaz xBz xcz x-z x@z';

console.log(str.match(/x[a-zA-Z-]z/g));