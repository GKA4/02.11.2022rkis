let str = '1 23 456 789';

console.log(str.search(/\d\d\d/g));