let str = 'site.ru sss site.com zzz site.net';

console.log(str.match(/\w+\.\w{1,3}/g));