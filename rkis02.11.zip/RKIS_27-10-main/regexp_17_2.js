let str = 'aeeea aeea aea axa axxa axxxa';

console.log(str.match(/a(e{2}|x+)a/g));