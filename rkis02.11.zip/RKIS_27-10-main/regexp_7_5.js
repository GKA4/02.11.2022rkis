let str = 'ave a#b a2b a$b a4b a5b a-b acb';

console.log(str.match(/a\Wb/g));