let str = 'aba aca aea abba adca abea';

console.log(str.match(/a..a/g));