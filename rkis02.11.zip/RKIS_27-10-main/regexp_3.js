let str = 'ab abab abab abababab abea';

console.log(str.match(/(ab)+/g));   