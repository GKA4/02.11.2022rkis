let str = 'aba aca aea abba adca abea';

console.log(str.match(/ab.a/g));