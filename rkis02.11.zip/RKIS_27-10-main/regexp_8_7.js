let str = 'aAXa aeffa aGha aza ax23a a3sSa';

console.log(str.match(/a[a-zA-Z]+a/g));