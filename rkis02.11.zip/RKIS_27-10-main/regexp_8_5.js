let str = 'aAa aea aEa aJa a3a';

console.log(str.match(/a[a-fA-D]a/g));