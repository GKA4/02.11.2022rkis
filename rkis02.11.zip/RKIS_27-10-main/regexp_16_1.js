let str = 'abc def xyz';

console.log(str.match(/^[a-z]+/g));