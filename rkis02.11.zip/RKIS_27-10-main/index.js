let str = 'string aaaa dd awidjmaw gfff ggbbb easdg dcwasdvjjlkwq';
console.log(str.replace(/[a-zA-Z]*([a-zA-Z])\1[a-zA-Z]*/g, ''));