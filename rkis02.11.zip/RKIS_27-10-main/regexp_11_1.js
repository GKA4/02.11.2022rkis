let str = 'aba aea aca aza axa a.a a+a a*a';

console.log(str.match(/a[.+*]a/g));