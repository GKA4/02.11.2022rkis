let str = '2+3 223 2223';

console.log(str.match(/2\+3/g));