let str = 'ahb acb aeb aeeb adcb axeb';

console.log(str.match(/a.b/g));