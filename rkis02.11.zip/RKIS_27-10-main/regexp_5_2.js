let str = 'aa aba abba abbba abbbba abbbbba';

console.log(str.match(/ab{1,3}a/g));