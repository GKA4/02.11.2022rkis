let str = '2025-12-31 12:59:59';

console.log(str.split(/[-:\s]/));