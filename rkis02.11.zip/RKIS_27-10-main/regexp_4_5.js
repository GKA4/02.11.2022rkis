let str = '*+ *q+ *qq+ *qqq+ *qqq qqq+';

console.log(str.match(/\*q+\+/g));